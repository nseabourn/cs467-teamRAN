#ifndef COMMON_hpp
#define COMMON_hpp

extern WINDOW* stdscr;
extern WINDOW* win;
extern WINDOW* borderWindow;
extern const char* hitButton;
extern const int newWidth;

#endif